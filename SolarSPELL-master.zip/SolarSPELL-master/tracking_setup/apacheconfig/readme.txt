make a backup copy of the original 000-default.conf in /etc/apache2/sites-available/

copy 000-default.conf in this directory to /etc/apache2/sites-available/

restart apache with the command:
sudo service apache2 restart

